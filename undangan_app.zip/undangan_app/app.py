"""
Modul untuk aplikasi manajemen undangan berbasis Flask.
Menangani login, pengisian form, penyimpanan database, dan pembuatan PDF.
"""

import mysql.connector
from flask import Flask, render_template, request, redirect, session, send_file
from reportlab.lib.pagesizes import A4
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,TableStyle, HRFlowable)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY

import config

app = Flask(__name__)
app.secret_key = "undangan123"


def get_db_connection():
    """Membuat koneksi ke database MySQL berdasarkan konfigurasi."""
    return mysql.connector.connect(
        host=config.MYSQL_HOST,
        user=config.MYSQL_USER,
        password=config.MYSQL_PASSWORD,
        database=config.MYSQL_DB
    )


@app.route("/login", methods=["GET", "POST"])
def login():
    """Menangani otentikasi pengguna."""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM users WHERE username=%s AND password=%s",
                (username, password)
            )
            user = cursor.fetchone()
            conn.close()

            if user:
                session["login"] = True
                return redirect("/form")
        except mysql.connector.Error as err:
            print(f"Login Database Error: {err}")

    return render_template("login.html")

@app.route("/delete/<int:id>", methods=["GET","POST"])
def delete(id):
    if not session.get("login"):
        return redirect("/")

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM undangan WHERE id=%s", (id,))
    conn.commit()
    conn.close()

    return redirect("/history")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/landing")

@app.route("/landing")
def landing():
    return render_template("landing.html")


@app.route("/form")
def form():
    """Menampilkan halaman form pengisian undangan."""
    if not session.get("login"):
        return redirect("/")
    return render_template("form.html")


@app.route("/save", methods=["POST"])
def save():
    """Menyimpan data undangan ke database dan menghasilkan PDF."""
    d = {
        "nomor": request.form["nomor"],
        "tujuan": request.form["tujuan"],
        "jabatan": request.form["jabatan"],
        "alamat": request.form["alamat"],
        "tgl_surat": request.form["tanggal_tempat_surat"],
        "isi": request.form["isi_surat"],
        "hari_tgl": request.form["hari_tanggal"],
        "jam": request.form["jam"],
        "tempat": request.form["tempat"]
    }

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = """INSERT INTO undangan
                   (nomor, tujuan, jabatan, alamat, tanggal_surat,
                    isi_surat, hari_tanggal, jam, tempat)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
        cursor.execute(query, list(d.values()))
        conn.commit()
        conn.close()
    except mysql.connector.Error as err:
        print(f"Database Save Error: {err}")

    pdf_fn = "undangan.pdf"
    buat_pdf(d, pdf_fn)

    return send_file(pdf_fn, as_attachment=True)


@app.route("/history")
def history():
    """Menampilkan riwayat undangan yang telah dibuat."""
    if not session.get("login"):
        return redirect("/")
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM undangan ORDER BY id DESC")
    data = cursor.fetchall()
    conn.close()
    return render_template("history.html", data=data)


def buat_pdf(d, filename):
    """
    Menghasilkan file PDF undangan.
    Variabel dikelompokkan untuk menghilangkan R0914 dan C0301.
    """
    doc = SimpleDocTemplate(
        filename, pagesize=A4,
        rightMargin=2*cm, leftMargin=2*cm,
        topMargin=1.5*cm, bottomMargin=1.5*cm
    )

    # Dictionary styles untuk mengurangi variabel lokal
    st = {
        'h': ParagraphStyle(name='H', fontSize=11, alignment=TA_CENTER, leading=14),
        'n': ParagraphStyle(name='N', fontSize=10, alignment=TA_JUSTIFY, leading=14),
        'r': ParagraphStyle(name='R', alignment=2, fontSize=10)
    }

    elements = []

    # Kop Surat & Tanggal
    hdr = (
        '<font size="14"><b>Politeknik Negeri Batam</b></font><br/>'
        'Politeknik Negeri Batam, Gedung Utama Lt. 1, Politeknik Negeri Batam, Jl. Ahmad Yani, Tlk. Tering, Kec. Batam Kota, Batam, Riau Islands Province<br/>'
        'Telp +62-778-469858, Fax : +62-778-463620<br/>'
        'email : info@polibatam.ac.id , www.polibatam.ac.id'
    )
    elements.extend([
        Paragraph(hdr, st['h']), Spacer(1, 0.2*cm),
        HRFlowable(width="100%", thickness=2, color=colors.navy, spaceAfter=0.1*cm),
        Spacer(1, 0.5*cm), Paragraph(d['tgl_surat'], st['r']), Spacer(1, 0.5*cm)
    ])

    # Tabel Nomor
    t1 = Table([['Nomor', ':', d['nomor']], ['Lampiran', ':', '-'],
                ['Hal', ':', 'Undangan Rapat']], colWidths=[2.2*cm, 0.4*cm, 8*cm], hAlign='LEFT')
    t1.setStyle(TableStyle([('FONTSIZE', (0, 0), (-1, -1), 10), ('LEFTPADDING', (0, 0), (-1, -1), 0)]))
    elements.extend([t1, Spacer(1, 0.8*cm)])

    # Isi Surat
    penerima = f"Kepada Yth.<br/><b>{d['tujuan']}</b><br/>{d['jabatan']}<br/>{d['alamat']}"
    elements.extend([
        Paragraph(penerima, st['n']), Spacer(1, 0.8*cm),
        Paragraph("Dengan hormat,", st['n']), Spacer(1, 0.3*cm),
        Paragraph(d['isi'], st['n']), Spacer(1, 0.5*cm)
    ])

    # Tabel Jadwal
    t2 = Table([['Hari/tanggal', ':', d['hari_tgl']], ['Jam', ':', d['jam']],
                ['Tempat', ':', d['tempat']]], colWidths=[3.2*cm, 0.4*cm, 10*cm], hAlign='LEFT')
    t2.setStyle(TableStyle([('FONTSIZE', (0, 0), (-1, -1), 10), ('LEFTPADDING', (0, 0), (-1, -1), 0)]))
    elements.extend([t2, Spacer(1, 0.8*cm)])

    # Penutup & Tanda Tangan
    pntp = ("Demikian surat undangan ini kami sampaikan, mengingat betapa pentingnya "
            "acara ini kami sangat mengharapkan kehadiran dari Bapak/Ibu tepat waktu. "
            "Atas perhatiannya kami ucapkan banyak terima kasih.")
    ttd_data = [['', 'Hormat kami,'], ['', 'Direktur Utama'], ['', 'Politeknik Negeri Batam'],
                ['', ''], ['', ''], ['', ''], ['', 'Ir Bambang Hendrawan ST, MSM']]
    t3 = Table(ttd_data, colWidths=[10*cm, 7.5*cm])
    t3.setStyle(TableStyle([('ALIGN', (1, 0), (1, -1), 'LEFT'), ('FONTSIZE', (0, 0), (-1, -1), 10)]))
    elements.extend([Paragraph(pntp, st['n']), Spacer(1, 1.2*cm), t3])

    doc.build(elements)


if __name__ == "__main__":
    app.run(debug=True)
